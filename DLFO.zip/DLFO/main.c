#define BAUD 9600
#define BAUD_TOL 2

#include <avr/io.h>
#include "spi3.h"
#include <stdint.h>
#include <stddef.h>
#include <util/delay.h>
#include "ADClib.h"
#include "stdio_setup.h"
#include <stdio.h>
#include <math.h>
#include <avr/interrupt.h>
#include "MCP4921.h"


uint8_t WFMFREQ = 100; // max rate hz for sq wave
uint16_t CV = 0;

volatile uint16_t c = 0; // counter in ISR
void SPI_TransferTx16(uint8_t a, uint8_t b);

ISR (TIMER0_COMPA_vect);
void ramp(uint16_t freq);
void tri(uint16_t freq);
void squarewave(uint16_t freq);
uint16_t count = 0; // global counter for waveforms


//clock setup
void timer_start(void);
// an interrupt is triggered each time the interval occurs.


//ISR routines have to go BEFORE main{}

ISR (TIMER0_COMPA_vect)  // timer0 overflow interrupt
{
	c++;
	
}



int main(void)
{
	
	//set up stdio_setup
	UartInit();
	ADC_init();
    //initialize SPI
    
	init_spi_master();
    spi_mode(0);
	DESELECT();
	SELECT();

	//********TIMER************
	
	// Set the Timer 0 Mode to CTC
	TCCR0A |= (1 << WGM01);

	// Set the value that you want to count to
	OCR0A = 0xFF;

	TIMSK0 |= (1 << OCIE0A);    //Interrupt fires when counter matches OPR0A value above.

	sei();         //enable interrupts  
	// in atmel s7 sei() is flagged as red squiggle due to 
	//"intellisence" beautifying,but will still compile. Doh!


    //TCCR0B |= (1 << CS02); DO NOT USE, this turns off clock
	TCCR0B |= (1 << CS01);
	TCCR0B |= (0 << CS00);
	// set preschooler to 64 and start the timer
	
    //********TIMER************
	

	
	while (1)
	{
	
		
		CV = analogRead10bit();
	  
	    {
		ramp(CV);
		//tri(CV);
		//squarewave(CV);
		}

	}
}



void ramp(uint16_t freq)
{
	
	uint16_t rate = 0;

	rate = 1024-freq;

	

		if (c >= rate)
		  {
			
			   //next 2 lines for debug   
              //printf("ramp rate: %d",rate);
             // printf("ramp ccccc: %d",c); 	      
       
			 count = count + WFMFREQ;
	         uint8_t CMSB = count >> 8;
			 uint8_t CLSB = count & 0xFF;
		     write4921(CMSB,CLSB);
			 count++;
			 
			 
			 //next 2 lines for debug
			// printf("ramp count: %d \n\r",count);
			// printf("ramp bytes %x %x \n\r",CMSB,CLSB);
		     c = 0; 
             if (count > 4096)
             {
	             count = 0;
             }		 	  
		  }
		
	  
	   if (c >= 25000)
	  {
		  c = 0;
	  }
	  
}

void squarewave(uint16_t freq)
{
	
	uint16_t rate = 0;

	rate = 1024-freq;

	

	if (c >= rate)
	{
		
		
		count = count + WFMFREQ;
		if (count > 2047)
		{

		write4921(0,0);
		
		}
		
		else
		{
		write4921(0x0F,0xFF);	
		}
		count++;
		//next 2 lines for debug
		// printf("sqwave count: %d \n\r",count);
		// printf("sqwave bytes %x %x \n\r",CMSB,CLSB);
		c = 0;
		if (count > 4096)
		{
			count = 0;
		}
	}
	
	
	if (c >= 25000)
	{
		c = 0;
	}

	
}

 void tri(uint16_t freq)
 {
	 
	 uint16_t rate = 0;

	 rate = 1024-freq;
   

	 if (c >= rate)
	 {
	 
		 //next 2 lines for debug
		 //printf("input rate: %d",rate);
		 // printf("tri ccccc: %d",c);
		 
		 if (count < 4096 + WFMFREQ)
		    {
		    count = count + WFMFREQ;	
			uint8_t CMSB = count >> 8;
			uint8_t CLSB = count & 0xFF;
			write4921(CMSB,CLSB);
			count++;
			  	
			}
		

		 if (count >= 4096 + WFMFREQ)
			{		     
            
			 count = count + WFMFREQ;
			  
			 uint16_t triout = 4096 - (count - 4096);
			 uint8_t CMSB = triout >> 8;
			 uint8_t CLSB = triout & 0xFF;
			 write4921(CMSB,CLSB);
             count++;
    			
		    			}
         if (count > 8192 + WFMFREQ)
		 {
			
	         count=0;
	         
		 }
		 c = 0;

	 }
	 
 }
 