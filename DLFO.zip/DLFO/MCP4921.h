/*
 * MCP4921.h
 *
 * Created: 3/22/2021 11:14:44 AM
 *  Author: clamm
 */ 


#ifndef MCP4921_H_
#define MCP4921_H_

void write4921(uint8_t MSB, uint8_t LSB);



#endif /* MCP4921_H_ */